import math
n=int(input("Enter the number whose factorial you want to find"))
print("The factorial of the number is :")
print(math.factorial(n))